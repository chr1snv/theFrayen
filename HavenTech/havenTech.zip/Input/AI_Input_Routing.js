//# sourceURL=Input/AI_Input_Routing.js
// client-router.js (browser-only)
// Minimal UI hookup

	// ---------- CONFIG & HELPERS ----------
	const SOLVERS = { SAT: 'SAT', CAS: 'CAS', LTN: 'LTN', LLM: 'LLM' };
	const SESSION_KEY = 'solver_router_session_v1';

	function now() { return Date.now(); }

	// Simple in-browser session/world store (localStorage)
	const Store = {
		load() {
			try { 
				return JSON.parse(localStorage.getItem(SESSION_KEY)) || { sessions: {} };
			}catch(e){
				return {
					sessions: {}
				};
			}
		},
		save(data) { 
			localStorage.setItem(SESSION_KEY, JSON.stringify(data));
		},
		getSession(sid) {
			const d = Store.load();
			d.sessions[sid] = d.sessions[sid] || { events: [], policyWeights: { SAT:0, CAS:0, LTN:0, LLM:0 } };
			return d.sessions[sid];
		},
		appendEvent(sid, ev) {
			const all = Store.load();
			all.sessions[sid] = all.sessions[sid] || { events: [], policyWeights: { SAT:0, CAS:0, LTN:0, LLM:0 } };
			all.sessions[sid].events.push(ev);
			if (all.sessions[sid].events.length > 50) 
				all.sessions[sid].events.shift();
			Store.save(all);
		},
		updatePolicy(sid, solver, delta) {
			const all = Store.load();
			all.sessions[sid] = all.sessions[sid] || { events: [], policyWeights: { SAT:0, CAS:0, LTN:0, LLM:0 } };
			all.sessions[sid].policyWeights[solver] = (all.sessions[sid].policyWeights[solver]||0) + delta;
			Store.save(all);
		}
	};

	// Lightweight text heuristics
	function textHeuristic(text) {
		if (!text)
			return null;
		const t = text.toLowerCase();
		if (/\b(sat|cnf|tseytin|boolean|satisfy|satisfiability)\b/.test(t))
			return SOLVERS.SAT;
		if (/\b(solve|factor|integral|derivative|polynomial|groebner|gr\"obner|equation|=)\b/.test(t))
			return SOLVERS.CAS;
		if (/\b(rule|forall|exists|predicate|fuzzy|logic tensor|ltn|constraint|implication)\b/.test(t))
			return SOLVERS.LTN;
		if (/\b(explain|summarize|translate|generate|write|code)\b/.test(t))
			return SOLVERS.LLM;
		return null;
	}

	// Very basic multimodal heuristic
	function multimodalClassify({ text, hasImage, hasAudio }, session) {
		const h = textHeuristic(text);
		if (h) 
			return { solver: h, reason: 'text_heuristic' };

		// use session policy weights to bias decision
		const weights = session.policyWeights || { SAT:0, CAS:0, LTN:0, LLM:0 };

		if (hasImage && /math|equation|diagram/i.test(text||''))
			return { solver: SOLVERS.CAS, reason: 'image+math' };
		if (hasAudio && !text)
			return { solver: SOLVERS.LLM, reason: 'audio_fallback' };

		// fallback: pick highest policy weight or LTN as conservative default
		const sorted = Object.keys(weights).sort((a,b)=>weights[b]-weights[a]);
		const winner = (weights[sorted[0]]>0) ? sorted[0] : SOLVERS.LTN;
		return { solver: winner, reason: 'policy_fallback' };
	}

	// ---------- STUBBED SOLVER CALLS (replace with real APIs/WASM) ----------
	async function callSAT(text, imageBlob, audioBlob) {
		// In reality: parse formula, Tseytin CNF, call WASM/minisat or remote Z3 API
		await sleep(120); // simulate
		return { ok:true, solver:'SAT', summary: 'Stub SAT run; parsed CNF and searched for model' };
	}
	async function callCAS(text, imageBlob, audioBlob) {
		// In reality: OCR image -> SymPy call or WASM CAS
		await sleep(150);
		return { ok:true, solver:'CAS', summary: 'Stub CAS run; attempted symbolic solve' };
	}
	async function callLTN(text, imageBlob, audioBlob) {
		// In reality: send features to LTN service or local TF.js model
		await sleep(200);
		return { ok:true, solver:'LTN', summary: 'Stub LTN run; estimated soft-satisfaction scores' };
	}
	async function callLLM(text, imageBlob, audioBlob) {
		await sleep(140);
		return { ok:true, solver:'LLM', summary: 'Stub LLM response (parsing/translation/generation)' };
	}
	function sleep(ms){ 
		return new Promise(r=>setTimeout(r,ms));
	}


	// ---------- GRAPH SCENE BUILDER for GRPH_Draw ----------
	// We produce a minimal graph object with 
	//havenScene.cameras[0] and rastB.mdls structure expected by your renderer.
	// Node format: { id: 'node1', label: 'SAT', origin: [x,y,z], color: [r,g,b,a] }
	
	// build a small graph scene from decision/session/result
	function buildGraphScene(graphName, decision, session, result){
		const gph = new Graph(graphName||'sceneGraph');

		// center input node
		const inputKey = 'input';
		GRPH_AddEntry(gph, new GraphEntry(inputKey));
		// solver node
		const solverKey = 'solver:'+decision.solver;
		GRPH_AddEntry(gph, new GraphEntry(solverKey));
		GRPH_AddLink(gph, inputKey, solverKey, 'routed', 1.0);
		// result node
		const resKey = 'result:'+short(result && result.summary ? result.summary : 'pending', 32);
		GRPH_AddEntry(gph, new GraphEntry(resKey));
		GRPH_AddLink(gph, solverKey, resKey, 'produces', 1.0);
		// session nodes (recent events)
		const sess = (session.events||[]).slice(-6);
		sess.forEach((e,i)=>{
			const sKey = `ev${i}:${e.decision?.solver||'?'}`;
			GRPH_AddEntry(gph, new GraphEntry(sKey));
			GRPH_AddLink(gph, inputKey, sKey, 'context', 0.6 + (e.feedback?.correct?0.6:0));
		} );
		
		// optionally connect similar past solvers to current solver
		const pastSolvers = {};
		(session.events||[]).forEach(e => { if(e.decision?.solver) pastSolvers[e.decision.solver]=true; });
		Object.keys(pastSolvers).forEach(ps=>{
				const sk = 'solver:'+ps;
				if(!gph.graphEntries[sk])
					GRPH_AddEntry(gph, new GraphEntry(sk));
					GRPH_AddLink(gph, sk, solverKey, 'sim', 0.3);
				} );

		// do layout with input as root
		const scene = layoutGraphRadial(gph, inputKey, 1.5);

		return scene;
	}
	

/*
function GraphLink(target, type, strength){
	this.type = type;
	this.strength = strength;
	this.target = target;
}

function GraphEntry(val){
	this.val = val;
	this.links = {};
	this.minRadius = 2; //the distance where the node will start pushing away other objects
}
*/
	
	function buildGraphForDecision(decision, session, result) {
		// Simple layout: central input node, solver node, result node, session nodes around
		const inputNode = { 
			val:'Input',
			origin:[0,0,0],
			color:[1,1,1,1]
		};
		const solverNode = { 
			val:decision.solver,
			origin:[1.2,0,0],
			color: solverColor(decision.solver)
		};
		const resultNode = {
			val: result && result.summary ? short(result.summary) : 'pending', 
			origin:[2.4,0,0], 
			color:[0.6,0.6,0.6,1]
		};

	// session context nodes (last 4 events)
	const sess = (session.events||[]).slice(-4);
	const sessionNodes = sess.map( (e,i)=>({
		 val: (e.decision?.solver||'') + ':' + (e.feedback?.correct ? 'OK':'?'),
		 origin:[0, -1.2 - i*0.9, 0],
		 color:[0.2,0.7,0.2,1]    })
		 );

	// edges as simple pairs for drawing (we'll just queue text labels at node origins)
	const nodes = [inputNode, solverNode, resultNode, ...sessionNodes];
	return { nodes, edges: [ ['input','solver'], ['solver','result']
							].concat(sessionNodes.map(n=>['input',n.id])) };
	}
	function solverColor(s) {
		switch(s){
			case SOLVERS.SAT: return [1,0.4,0.2,1];
			case SOLVERS.CAS: return [0.2,0.6,1,1];
			case SOLVERS.LTN: return [0.9,0.8,0.2,1];
			case SOLVERS.LLM: return [0.6,0.3,0.9,1];
		}
		return [0.5,0.5,0.5,1];
	}
	function short(str, n=24){ return str.length>n?str.slice(0,n-1)+'…':str; }

	// populate rastB.mdls with nodes so your GRPH_Draw will render labels via TR_QueueText
	function populateRasterBatchFromScene(gph, rastB, scene) {
		rastB.mdls = rastB.mdls || {};
		// clear previous few nodes (simple approach)
		rastB.mdls = {};
		scene.nodes.forEach((n, idx) => {
			rastB.mdls['node'+idx] = {
				modelName: n.label,
				origin: n.origin.slice(),
				// additional fields if your renderer expects more
			};
		});
		// Optionally store edges in rastB for line drawing elsewhere
		rastB.sceneEdges = scene.edges;
	}


	// ---------- MAIN UI & Flow ----------

	//submitBtn.addEventListener('click', ()=>this.handleSubmit());
	var aiSession = Store.getSession(0);

	async function submitPrompt(text, imgFile, audFile, session) {
		const hasImage = !!imgFile;
		const hasAudio = !!audFile;
		const decision = multimodalClassify({ text, hasImage, hasAudio }, session);
		
		// record initial event
		const event = { t: now(), input: { text: short(text,80), hasImage, hasAudio }, decision, feedback: null };
		Store.appendEvent(this.sessionId, event);

		// present parsing/routing description
		const desc = `Parser routed input → ${decision.solver} (${decision.reason})`;
		DPrintf( desc );

		// call solver stub
		let result;
		switch(decision.solver){
			case SOLVERS.SAT: result = await callSAT(text, imgFile, audFile); break;
			case SOLVERS.CAS: result = await callCAS(text, imgFile, audFile); break;
			case SOLVERS.LTN: result = await callLTN(text, imgFile, audFile); break;
			case SOLVERS.LLM: default: result = await callLLM(text, imgFile, audFile);
			break;
		}

		// record result event
		event.result = result;
		Store.appendEvent(this.sessionId, event);

		// update policy weights slightly based on stub heuristics (no real feedback yet)
		Store.updatePolicy(this.sessionId, decision.solver, +1);

		// build small scene and populate rastB for GRPH_Draw
		session.graph = buildGraphForDecision(decision, session, result);

		// optionally display more detail
		DPrintf( desc + '\n' + (result.summary || JSON.stringify(result)) );
	}

	// API to receive user feedback and update policy & world
	function submitFeedback(correct, notes) {
		const session = Store.getSession(this.sessionId);
		const last = session.events[session.events.length-1];
		if (!last)
			return;
		last.feedback = { correct: !!correct, notes: notes||'' };
		Store.appendEvent(this.sessionId, last);
		// reward/punish solver policy
		const solver = last.decision?.solver;
		if (solver)
			Store.updatePolicy(this.sessionId, solver, correct ? +3 : -2);
	}


// Expose to global for debug
window.__SR_store = Store;
