
// --- ASCII PARSED GRAPH TREE LOGGER ---
function logAsciiParsedGraph(wordsArray, numTokens) {
  let totalArcs = stateMemory[MEM_ARC_PTR];
  let arcBase = MEM_STK_FRM_SZ + (MAX_TOKENS * 2);
  
  console.log(`\n=== ASCII PARSED GRAPH MATRIX (${totalArcs} Arcs) ===`);
  
  let a = 0;
  while (a < totalArcs) {
    let headIdx = stateMemory[arcBase + a];
    let depIdx  = stateMemory[arcBase + MAX_TOKENS + a];
    let relType = stateMemory[arcBase + (MAX_TOKENS * 2) + a];
    
    let headWord = wordsArray[headIdx];
    let depWord  = wordsArray[depIdx];
    
    // Map numerical output indices back to labels
    let label = "dep";
    if (relType === 28) label = "nsubj";
    else if (relType === 30) label = "obj";
    else if (relType === 17) label = "det";
    
    // Visual node flow representation
    if (headIdx > depIdx) {
      console.log(`  ${depWord} <───(${label})─── ${headWord}`);
    } else {
      console.log(`  ${headWord} ───(${label})───> ${depWord}`);
    }
    a = a + 1;
  }
  console.log("==================================================\n");
}

// --- ZERO-ALLOCATION VALIDATION SCORER ---
function evaluateDatasetAccuracy(datasetSegment) {
  let correctSteps = 0;
  let totalSteps = 0;
  
  let itemIdx = 0;
  while (itemIdx < datasetSegment.length) {
    let item = datasetSegment[itemIdx];
    let tokens = item.tokens;
    let posTags = item.posTags;
    let recipe = item.goldRecipe;
    
    let stepIdx = 0;
    while (stepIdx < recipe.length) {
      let step = recipe[stepIdx];
      let s0_word = (step.s0_idx === -1) ? "" : tokens[step.s0_idx];
      let b0_word = (step.b0_idx === -1) ? "" : tokens[step.b0_idx];
      let s0_pos = (step.s0_idx === -1) ? 0 : posTags[step.s0_idx];
      let b0_pos = (step.b0_idx === -1) ? 0 : posTags[step.b0_idx];
      
      let stateFeatureIndex = (s0_pos * NUM_POFSPCH) + b0_pos;
      if (step.isPassiveContext === 1) stateFeatureIndex += (NUM_POFSPCH * NUM_POFSPCH);
      
      computeSemanticHashInline(s0_word, vecS0);
      computeSemanticHashInline(b0_word, vecB0);
      
      let bestActionID = 0;
      let highestScore = -999999.0;
      let actionIdx = 0;
      
      while (actionIdx < NUM_ACTIONS) {
        let score = 0.0;
        let dimIdx = 0;
        let baseOffset = (stateFeatureIndex * TOKEN_VEC_DIM * NUM_ACTIONS) + (actionIdx * TOKEN_VEC_DIM);
        while (dimIdx < TOKEN_VEC_DIM) {
          score += (vecS0[dimIdx] + vecB0[dimIdx]) * multiModalWeights[baseOffset + dimIdx];
          dimIdx++;
        }
        if (score > highestScore) { highestScore = score; bestActionID = actionIdx; }
        actionIdx++;
      }
      
      if (bestActionID === step.actionID) correctSteps++;
      totalSteps++;
      stepIdx++;
    }
    itemIdx++;
  }
  return totalSteps === 0 ? 0 : (correctSteps / totalSteps) * 100;
}

// --- MASTER AUTOMATED TRAIN/VALIDATION ENGINE RUNNER ---
function runSplitTrainingEngine(fullDataset, epochs, baseLearningRate) {
  // Shuffle dataset array inline using Fisher-Yates to randomize instances
  let m = fullDataset.length, t, i;
  while (m) {
    i = Math.floor(Math.random() * m--);
    t = fullDataset[m];
    fullDataset[m] = fullDataset[i];
    fullDataset[i] = t;
  }
  
  // Create strict 80/20 data partition boundaries
  let trainCount = Math.floor(fullDataset.length * 0.8);
  let trainSet = fullDataset.slice(0, trainCount);
  let valSet   = fullDataset.slice(trainCount);
  
  console.log(`Allocated ${trainSet.length} Training items | ${valSet.length} Validation check items.`);
  multiModalWeights.fill(0); // Safely zero memory allocations before compilation cycles
  
  let epoch = 0;
  while (epoch < epochs) {
    let learningRate = baseLearningRate / (1.0 + (epoch * 0.1));
    
    // Core optimization pass using training slice
    let itemIdx = 0;
    while (itemIdx < trainSet.length) {
      let item = trainSet[itemIdx];
      let tokens = item.tokens;
      let posTags = item.posTags;
      let recipe = item.goldRecipe;
      
      let stepIdx = 0;
      while (stepIdx < recipe.length) {
        let step = recipe[stepIdx];
        let s0_word = (step.s0_idx === -1) ? "" : tokens[step.s0_idx];
        let b0_word = (step.b0_idx === -1) ? "" : tokens[step.b0_idx];
        let s0_pos = (step.s0_idx === -1) ? 0 : posTags[step.s0_idx];
        let b0_pos = (step.b0_idx === -1) ? 0 : posTags[step.b0_idx];
        
        let stateFeatureIndex = (s0_pos * NUM_POFSPCH) + b0_pos;
        if (step.isPassiveContext === 1) stateFeatureIndex += (NUM_POFSPCH * NUM_POFSPCH);
        
        // Mutates weights inline on misclassification
        trainStep(stateFeatureIndex, step.actionID, s0_word, b0_word, learningRate);
        stepIdx++;
      }
      itemIdx++;
    }
    
    // Evaluate generalization performance across splits
    let trainAcc = evaluateDatasetAccuracy(trainSet);
    let valAcc   = evaluateDatasetAccuracy(valSet);
    
    console.log(`Epoch ${epoch + 1}/${epochs} -> Train Acc: ${trainAcc.toFixed(1)}% | Val Acc: ${valAcc.toFixed(1)}%`);
    
    if (trainAcc === 100.0 && valAcc === 100.0) {
      console.log(`🎉 Generalization achieved! Zero validation losses recorded at Epoch ${epoch + 1}.`);
      break;
    }
    epoch++;
  }
}

//reset trained model before running split training
multiModalWeights.fill(0);

// Test execution run sequence configuration block
runSplitTrainingEngine(generatedFiftySixVariants, 40, 0.2);

// Check custom question formats live
const checkResult = extractSPO("where are we", window.WinkNLP.nlp);
logAsciiParsedGraph(["where", "are", "we"], 3);
console.log("Extracted Target Graph Context:", checkResult);

