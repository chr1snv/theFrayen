//# sourceURL=Transforms/LTN.js
// LTN.js - browser-side minimal Logic Tensor Network style pipeline using TF.js
// Requires tfjs loaded as global `tf`
// Exports: callLTN(input): runs inference; trainLTN(exampleBatch): trains model incrementally

const LTN = (function(){

	// ---------- CONFIG ----------
	const EMBED_DIM = 64;
	const IMG_EMBED_DIM = 128;
	const AUDIO_EMBED_DIM = 64;
	const PRED_HIDDEN = 64;
	const LEARNING_RATE = 1e-3;
	const USE_LUKASIEWICZ = true; // choose fuzzy ops

	// simple local store for learned embeddings / rule weights
	const STORE_KEY = 'ltn_world_v1';

	function loadStore(){
		try {
			return JSON.parse(localStorage.getItem(STORE_KEY)) || { entities:{}, rules:{}};
		}catch(e){ 
			return { entities:{}, rules:{}}; 
		}
	}
	function saveStore(s){
		localStorage.setItem(STORE_KEY, JSON.stringify(s));
	}

	// ---------- Encoders ----------
	// Text encoder: tiny char/word hashing -> dense projection (no external model)
	function textToEmbeddingSync(text){
		text = String(text||'').toLowerCase().slice(0,256);
		const vec = new Float32Array(EMBED_DIM).fill(0);
		for(let i=0;i<text.length;i++){
			const c = text.charCodeAt(i);
			const idx = Math.abs((c * (i+1)) % EMBED_DIM);
			vec[idx] += 1.0;
		}
		// normalize
		let norm = 0;
		for(let i=0;i<EMBED_DIM;i++)
			norm += vec[i]*vec[i];
			norm = Math.sqrt(Math.max(1e-6,norm));

		for(let i=0;i<EMBED_DIM;i++)
			vec[i] /= norm;
		return tf.tensor1d(vec);
	}
	// Image encoder: MobileNet v2 feature extractor via TF.js (lazy load)
	let mobilenetModel = null;
	async function imageToEmbedding(imgBlob){
		if(!imgBlob) return null;
		if(!mobilenetModel){
			mobilenetModel = await tf.loadGraphModel('https://tfhub.dev/google/imagenet/mobilenet_v2_140_224/classification/4', {fromTFHub:true}).catch(()=>null);
			// If above fails, try a simpler conv or fall back to random
		}
		if(!mobilenetModel) {
			// fallback: simple color histogram projection
			const arr = new Float32Array(IMG_EMBED_DIM).map(()=>Math.random()*0.01);
			return tf.tensor1d(arr);
		}
		// convert blob to tensor image
		const img = await createImageBitmap(imgBlob).catch(()=>null);
		if(!img)
			return null;
		const tfimg = tf.browser.fromPixels(img).toFloat().div(255).resizeBilinear([224,224]).expandDims(0);

		// mobileNet classification model output is logits; use pre-logits or pool layer if available
		const logits = mobilenetModel.predict(tfimg);
		const emb = tf.mean(logits, [0]); // crude pooling
		tfimg.dispose();
		logits.dispose();
		return emb.reshape([IMG_EMBED_DIM]).slice([0],[IMG_EMBED_DIM]).as1D().clone();
	}

	// Audio encoder: WebAudio -> mono PCM -> simple STFT -> mel-like summary -> small dense
	async function audioToEmbedding(audioBlob){
		if(!audioBlob)
			return null;
		const arrayBuf = await audioBlob.arrayBuffer();
		const ctx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, 44100);
		try{
			const decoded = await ctx.decodeAudioData(arrayBuf);
			const ch = decoded.getChannelData(0);
			// downsample / windowing: produce a simple energy-bin vector
			const frameSize = 1024;
			const hop = 512;      
			const bins = AUDIO_EMBED_DIM;      
			const out = new Float32Array(bins).fill(0);      
			let count=0;      
			for(let i=0;i+frameSize<ch.length;i+=hop){
				let energy=0;
				for(let j=0;j<frameSize;j++){
					const v = ch[i+j]; energy += v*v;
				}
				out[count % bins] += Math.sqrt(energy);
				count++;
			}
			// normalize
			let norm=0;
			for(let i=0;i<bins;i++)
				norm+=out[i]*out[i];
			norm=Math.sqrt(Math.max(1e-6,norm));
			for(let i=0;i<bins;i++)
				out[i]/=norm;
			return tf.tensor1d(out);
		}catch(e){
			// fallback
			return tf.tensor1d(new Float32Array(AUDIO_EMBED_DIM).map(()=>Math.random()*0.01));
		}
	}

	// ---------- Predicate network factory ----------
	function makePredicateNetwork(inDim){
		const model = tf.sequential();
		model.add(tf.layers.dense({ units: PRED_HIDDEN, activation: 'relu', inputShape: [inDim] }));
		model.add(tf.layers.dense({ units: 1, activation: 'sigmoid' })); // outputs in [0,1]
		return model;
	}

	// Example predicate registry: you can extend by name
	const predicates = {};
	function ensurePredicate(name, inDim){
		if(!predicates[name]) {
			predicates[name] = makePredicateNetwork(inDim);
		}
		return predicates[name];
	}

	// ---------- Fuzzy operators ----------
	function and_op(a,b){ // expects tf tensors scalar in [0,1]
		if(USE_LUKASIEWICZ){
			return tf.tidy(()=> tf.maximum(0, tf.add(a, b).sub(1)));
		} else {
			return tf.tidy(()=> a.mul(b));
		}
	}
	function or_op(a,b){
		if(USE_LUKASIEWICZ){
			return tf.tidy(()=> tf.minimum(1, tf.add(a,b)));
		} else {
			return tf.tidy(()=> tf.add(a,b).sub(a.mul(b)));
		}
	}
	function not_op(a){
		return tf.tidy(()=> tf.sub(1, a));
	}
	function implication(a,b){
		if(USE_LUKASIEWICZ){
			return tf.tidy(()=> tf.minimum(1, tf.add(tf.sub(1,a), b)));
		} else {
			// residuum-like: min(1, b / a) but avoid divide by zero; use 1 - a + a*b approx
			return tf.tidy(()=> tf.minimum(1, tf.add(tf.sub(1,a), a.mul(b))));
		}
	}

	// ---------- Rule evaluation (soft) ----------
	// rule structure: { name, body: fn(varBindings)->tf.scalar, head: fn(varBindings)->tf.scalar, weight: scalar }
	// For simplicity, we'll evaluate unary rules over a set of grounded entities.
	async function evaluateRuleSoft(rule, groundedEntities){
		// groundedEntities: array of objects { id, embTensor }
		const scores = [];
		for(const e of groundedEntities){
			const sBody = rule.body(e);
			const sHead = rule.head(e);
			const impl = implication(sBody, sHead); // tensor scalar
			scores.push(impl);
		}
		if(scores.length === 0) return tf.scalar(1.0); // vacuously true
		// aggregate via mean or softmin; use mean
		const stacked = tf.stack(scores);
		const mean = tf.mean(stacked);
		const weighted = mean.mul(rule.weight || 1.0);
		// cleanup
		scores.forEach(t=>t.dispose());
		stacked.dispose();
		return weighted;
	}

	// ---------- Model state & optimizer ----------
	const store = loadStore();
	const optimizer = tf.train.adam(LEARNING_RATE);

	// ---------- Public API: callLTN (inference) ----------
	async function callLTN_input({ text=null, imageBlob=null, audioBlob=null }){
		// produce embeddings
		const tEmb = text ? textToEmbeddingSync(text) : null;
		const iEmb = imageBlob ? await imageToEmbedding(imageBlob) : null;
		const aEmb = audioBlob ? await audioToEmbedding(audioBlob) : null;

		// compose a joint embedding (concatenate available)
		const parts = [];    if(tEmb) parts.push(tEmb);
		if(iEmb) parts.push(iEmb);
		if(aEmb) parts.push(aEmb);
		if(parts.length === 0){
			// nothing to do
			return { ok:false, error:'no input' };
		}
		const joint = tf.concat(parts, 0).reshape([1, parts.reduce((s,p)=>s + p.shape[p.shape.length-1], 0)]);
		// ensure a predicate (example: Predicate: Relevant(input))
		const inDim = joint.shape[1];
		ensurePredicate('Relevant', inDim);
		// run predicate
		const pred = predicates['Relevant'];
		const out = pred.predict(joint);
		const score = (await out.data())[0];

		// sample soft rule evaluation (if rules exist in store)
		const rules = store.rules || {};
		const ruleScores = {};
		for(const rname in rules){
			const ruleDef = rules[rname];
			// build rule functions from stored spec (simple unary rule over Relevant->SomeProp)
			// For this demo, assume ruleDef has headPredicate name and weight
			const headPredName = ruleDef.head;
			ensurePredicate(headPredName, inDim);
			const headPred = predicates[headPredName];
			const headOut = headPred.predict(joint);
			const headScore = (await headOut.data())[0];
			ruleScores[rname] = { weight: ruleDef.weight, headScore };
			headOut.dispose();
		}

		// cleanup
		parts.forEach(p=>p.dispose());
		joint.dispose();
		if(tEmb)
			tEmb.dispose();
		if(iEmb)
			iEmb.dispose();
		if(aEmb)
			aEmb.dispose();
		out.dispose();

		const result = { ok:true, solver:'LTN', summary:`Relevant score ${score.toFixed(3)}`, score, ruleScores };
		
		// optional classifier output
		if(predicates['AnswerClassifier']){
			const clf = predicates['AnswerClassifier'];
			const logits = clf.predict(joint);
			const probs = Array.from(await logits.data());
			const idx = probs.indexOf(Math.max(...probs));
			logits.dispose();
			result.answer = { label: labels[idx] || String(idx), probs };
		}
	}

	// ---------- Training helper: train on small batch of examples ----------
	// example: { text, imageBlob, audioBlob, labels: { PredName: 0/1 }, rules: [ optional rule specs ] }
	async function trainLTN_onBatch(examples, epochs=1){
		// build dataset tensors in memory (small batches)
		const inputs = [];
		const labelsMap = {}; // predName -> array of labels aligned to inputs
		for(const ex of examples){
			const tEmb = ex.text ? textToEmbeddingSync(ex.text) : null;
			const iEmb = ex.imageBlob ? await imageToEmbedding(ex.imageBlob) : null;
			const aEmb = ex.audioBlob ? await audioToEmbedding(ex.audioBlob) : null;
			const parts = [];
			if(tEmb) parts.push(tEmb);
			if(iEmb) parts.push(iEmb);
			if(aEmb) parts.push(aEmb);
			if(parts.length===0) continue;
			const joint = tf.concat(parts, 0).reshape([parts.reduce((s,p)=>s + p.shape[p.shape.length-1], 0)]);
			inputs.push(joint);
			if(ex.labels){
				for(const pname in ex.labels){
					labelsMap[pname] = labelsMap[pname] || [];
					labelsMap[pname].push(ex.labels[pname]);
				}
			}
			// store rules if provided
			if(ex.rules){
				ex.rules.forEach(r=>{
					store.rules[r.name] = { head: r.head, weight: r.weight || 1.0 };
				});
			}
			// cleanup small parts (joint stored)
			[tEmb,iEmb,aEmb].forEach(x=>{ if(x) x.dispose(); });
		}
		if(inputs.length===0)
			return { ok:false, error:'no valid inputs' };

		// stack inputs
		const X = tf.stack(inputs);
		// ensure predicate models exist for all label keys
		for(const pname in labelsMap){
			ensurePredicate(pname, X.shape[1]);
		}

		// training loop
		const losses = [];
		for(let ep=0; ep<epochs; ep++){
			// single step on all predicates independently (simpler)
			await optimizer.minimize(()=> {
				let totalLoss = tf.scalar(0);
				for(const pname in labelsMap){
					const yArr = labelsMap[pname];
					const y = tf.tensor1d(yArr).reshape([yArr.length,1]);
					const predModel = predicates[pname];
					const yHat = predModel.apply(X);
					const loss = tf.losses.sigmoidCrossEntropy(y, yHat).mean();
					totalLoss = totalLoss.add(loss);
					y.dispose(); yHat.dispose(); loss.dispose();
				}
				return totalLoss;
			}, true);
		}

		// cleanup
		X.dispose();
		inputs.forEach(t=>t.dispose());
		saveStore(store);
		return { ok:true, trainedOn: inputs.length };
	}
	// ---------- Exported functions ----------
	return {
		callLTN_input,
		trainLTN_onBatch,
		storeLoad: ()=> JSON.parse(JSON.stringify(store)), // snapshot
	};

})();
