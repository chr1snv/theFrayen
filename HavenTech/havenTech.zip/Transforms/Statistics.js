//# sourceURL=Transforms/Statistics.js

//cumulative distribution function cdf


