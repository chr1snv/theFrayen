//# sourceURL=Structures/CognitiveBayesianNeuroSymbolicNode.js

class CognitiveNode {
  constructor(dim = 64) {
    this.dim = dim;
    // Trainable "Control" Weights (Simulated as Scalars for Lightness)
    this.weights = {
      offset: Math.random(),
      width: Math.random(),
      gateThreshold: 0.5,
    };
    // Recurrent Hidden State (The "Summary")
    this.recurrentState = new Float32Array(dim).fill(0);
    // Knowledge Graph Memory
    this.graphDB = {};
  }


	// Bayesian Accumulation: AND (Multiplicative)
	// Improved Bayesian "AND" using a Sigmoid Gate to prevent vanishing values
	accumulateAND(windowVector, stateVector) {
	  return windowVector.map((val, i) => {
		// Sigmoid(A * B) acts as a soft-logic intersection
		// If both are high, result is high. If either is near zero, result is zero.
		const intersection = 1 / (1 + Math.exp(-(val * stateVector[i])));
		return intersection;
	  });
	}

  // Bayesian Accumulation: OR (Additive)
  // Used to merge the local window into the long-term recurrent state
  accumulateOR(localWindow, recurrentState) {
    return localWindow.map((val, i) => {
      const stateVal = recurrentState[i];
      // Novelty/Union logic (Bayesian Sum: P(A) + P(B) - P(A)P(B))
      return val + stateVal - (val * stateVal);
    });
  }

/*
  process(tokenStream, currentIndex) {
    // 1. Calculate Learned Window
    // Offset looks back, Width decides how many tokens to 'attend' to
    const lookback = Math.floor(this.weights.offset * 10);
    const windowSize = Math.ceil(this.weights.width * 5);
    
    const start = Math.max(0, currentIndex - lookback);
    const windowTokens = tokenStream.slice(start, start + windowSize);
    
    // 1. POOLING: Turn the window of tokens into one "Mean Vector"
	const windowVector = new Float32Array(this.dim).fill(0);
	windowTokens.forEach(t => {
		t.embedding.forEach((val, i) => windowVector[i] += val / windowTokens.length);
	});

    // 2. Bayesian Summarization
    // We "AND" to find recurring themes, then "OR" to add the newest specific info
    const summary = this.accumulateOR(windowVector, this.recurrentState);
    this.recurrentState = new Float32Array(summary);

    // 3. Selective Encoding (S-P-O Graph Entry Extraction) (subject,predicate,object triple)
    // If Information Gain is high enough, we commit to the Graph DB
    const infoGain = Math.abs(summary.reduce((a, b) => a + b) / this.dim);
    
    if (infoGain > this.weights.gateThreshold) {
      //this.commitToGraph(localWindow);
    }
  }

  commitToGraph(tokens) {
    // Symbolic transformation: In a real model, an MLP would map 
    // these embeddings to discrete Subject-Predicate-Object tokens
    const entry = {
      subject: tokens[0].text,
      predicate: "near",
      object: tokens[tokens.length - 1].text,
      timestamp: Date.now()
    };
    if( !this.graphDB[entry.subject] )
	    this.graphDB[entry.subject] = [entry];
	else
		this.graphDB[entry.subject].push(entry);
    console.log("Graph Mem Added:", entry);
  }
  */
  
  
	process(tokenStream, currentIndex) {
		// 1. Calculate Learned Window
		// Offset looks back, Width decides how many tokens to 'attend' to
		const lookback = Math.floor(this.weights.offset * 10);
		const windowSize = Math.ceil(this.weights.width * 5);
    
		const start = Math.max(0, currentIndex - lookback);
		const windowTokens = tokenStream.slice(start, start + windowSize);

		// 1. CALCULATE CENTROID (The context "summary")
		const centroid = this.calculateCentroid(windowTokens);

		// 2. APPLY BAYESIAN "AND" (Filtering)
		// We filter the centroid through the current state to find 'Relevant New Info'
		const relevantInfo = this.accumulateAND(centroid, this.recurrentState);

		// 3. APPLY BAYESIAN "OR" (Updating)
		// We add that relevant info into our long-term recurrent belief state
		this.recurrentState = this.accumulateOR(relevantInfo, this.recurrentState);

		// 4. GRAPH EXTRACTION (Symbolic "Fact" creation)
		// We look for the most "active" tokens in the window to form an SPO triple
		const bestToken = this.findHighestActivation(windowTokens, relevantInfo);
	  
		if (bestToken.score > this.weights.gateThreshold) {
			this.addToGraph(bestToken.text, "observed_in", "context", score);
		}
	}

	addToGraph(s, p, o, score) {
		if (!this.graphDB[s]) this.graphDB[s] = [];
		// Ensure we don't duplicate facts
		const exists = this.graphDB[s].some(entry => entry.p === p && entry.o === o);
		if (!exists) {
			this.graphDB[s].push({ p, o, strength: score });
		}
	}
  
}

// Example Usage
const mockTokens = [
  { text: "User", embedding: [0.9, 0.1] },
  { text: "likes", embedding: [0.2, 0.8] },
  { text: "Javascript", embedding: [0.5, 0.5] }
];

const node = new CognitiveNode(2);
mockTokens.forEach((_, i) => node.process(mockTokens, i));
