//# sourceURL=SceneLogic/sail/SailTextureSourcesAndCredits.js
"texure credits"
"skybox"
"bluecloud"
"https://opengameart.org/content/cloudy-skyboxes"

"sound credits"
"voiceovers by"
"stillelectric"

"menu music"
"https://pixabay.com/sound-effects/smooth-684-cm-54202/"
