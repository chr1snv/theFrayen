//# sourceURL=SceneLogic/sail/WindAndTide.js
//wind and tide direction and speed

function WNT_Update( time ){

}
